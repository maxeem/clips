﻿using System.Windows.Controls;

namespace CLIPSIDE
  {
   public partial class CloseableHeader : UserControl
     {
      public CloseableHeader()
        {
         InitializeComponent();
        }
     }
  }

