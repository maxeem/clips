See the CLIPS Interfaces Guide for instructions on
compiling and running Windows and CLIPSNET programs.